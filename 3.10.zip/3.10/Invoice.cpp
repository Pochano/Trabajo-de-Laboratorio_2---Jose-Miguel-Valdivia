#include <iostream>

class Invoid{

  private:

    std::string part_number;
    std::string part_description;
    int quantity_of_purchased;
    int price_per_item;
    double VAT = 0.20;
    double discount = 0;
    
  public:

    Invoid(std::string part_number, std::string part_description,int quantity_of_purchased,int price_per_item)

      : part_number{part_number}, part_description{part_description},           quantity_of_purchased{quantity_of_purchased},                            price_per_item{price_per_item} {}

    void getInvoiceAmount(){

      std::cout << "Invoice Amount with TAX and Discount: " << ((quantity_of_purchased*price_per_item)+((quantity_of_purchased*price_per_item)*VAT) - ((quantity_of_purchased*price_per_item)*discount)) << "\n";
      
    }


    std::string getpart_number(){
      return part_number;
    }
    std::string getpart_description(){
      return part_description;
    }
    int getquantity_of_purchased(){
      return quantity_of_purchased;
    }
    int getprice_per_item(){
      return price_per_item;
    }
    double getVAT(){
      return VAT;
    }
    double getdiscount(){
      return discount;
    }
    


};