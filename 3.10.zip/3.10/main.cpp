#include <iostream>
#include "Invoice.cpp"

int main() {
  Invoid factura("71457128", "Makro", 20, 30);
  std::cout << "In Invoice: \n" << factura.getpart_number() << "\n" <<
    factura.getpart_description() << "\n" << factura.getquantity_of_purchased() << "\n" << factura.getprice_per_item() << "\n" << factura.getVAT() << "\n" << factura.getdiscount() << "\n";
  factura.getInvoiceAmount();
}