#include <iostream>


class Motor_Vehicle
{
  private:
    std::string make;
    std::string fuel_type;
    std::string color;
    int year_of_manufacture = 0;
    int engine_capacity = 0;
  public:
    Motor_Vehicle(std::string make, std::string fuel_type, std::string color)
    : make{make}, fuel_type{fuel_type}, color{color}
{}

    void display_car_details(){

      std::cout << "Make: " << make << "\n";
      std::cout << "Fuel Type: " << fuel_type << "\n";
      std::cout << "Color: " << color << "\n";
      std::cout << "Year of manufacture: " << year_of_manufacture << "\n";
      std::cout << "Engine Capacity: " << engine_capacity << std:: endl;
    }

    std::string getmake() const{
      return make;
    }
    std::string getfuel_type() const{
      return fuel_type;
    }
    std::string getcolor() const{
      return color;
    }


};