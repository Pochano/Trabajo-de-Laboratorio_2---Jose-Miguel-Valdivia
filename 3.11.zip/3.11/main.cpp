#include <iostream>
#include "MotorVehicle.cpp"

int main() {

  Motor_Vehicle Carro1("Titanium", "Gas", "Red");
  Motor_Vehicle Carro2("Iron", "Petroleum", "Green");

  Carro1.display_car_details();
  std::cout << "\n";
  Carro2.display_car_details();

  std::cout << "\n";
  
  std::cout << "El material: " << Carro1.getmake() << "\n";
  std::cout << "El Combustible: " << Carro1.getfuel_type() << "\n";
  std::cout << "El color: " << Carro1.getcolor() << "\n";

  std::cout << "\n";

  std::cout << "El material: " << Carro2.getmake() << "\n";
  std::cout << "El Combustible: " << Carro2.getfuel_type() << "\n";
  std::cout << "El color: " << Carro2.getcolor() << "\n";
}