#include <iostream>

class Date{

  private:

    int day;
    int month = 1;
    int year;

  public:

    Date( int monthe, int day, int year)
      : day{day}, year{year} {
        if(monthe > 0 && monthe < 13){
          month = monthe;
        }
      }

    void displayDate(){
      std::cout << "Date: " << month << "/" << day << "/" << year << "\n"; 
    }

    int getday(){
      return day;
    }
    int getmonth(){
      return month;
    }
    int getyear(){
      return year;
    }


};