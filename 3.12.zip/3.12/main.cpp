#include <iostream>
#include "Date.cpp"

int main() {
  Date fecha1(04,2,2023);
  Date fecha2(1131231,25,2013);

  fecha1.displayDate();

  std::cout << "El mes es: " << fecha1.getmonth() << " el día es: " << fecha1.getday() << " y el año es: " << fecha1.getyear() << "\n";

  fecha2.displayDate();

  std::cout << "El mes es: " << fecha2.getmonth() << " el día es: " << fecha2.getday() << " y el año es: " << fecha2.getyear() << "\n";
  


  
}