#include <iostream>

class Account{

  private:

  int Account_Number;
  std::string First_Name;
  std::string Last_Name;
  double Balance;

  public:

    Account(int Account_Number, std::string First_Name, std::string Last_Name,double Balance)

  : Account_Number{Account_Number}, First_Name{First_Name}, Last_Name{Last_Name}, Balance{Balance} {}

  void mostrar(){

    std::cout << "Account_Number: " << Account_Number << "\n";
    std::cout << "First Name: " << First_Name << "\n";
    std::cout << "Last Name: " << Last_Name << "\n";
    std::cout << "Balance: " << Balance << "\n";

    
  }

};