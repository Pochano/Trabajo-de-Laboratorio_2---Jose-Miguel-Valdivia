#include <iostream>
#include "Account.cpp"

int main() {

  Account Cuenta1(71457128, "Jose", "Valdivia", 123.12);

  Cuenta1.mostrar();
  
}