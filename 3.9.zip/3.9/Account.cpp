#include <iostream>

class Account {

public:
	Account(std::string Account_Name, int Initial_Balance)
		: name{Account_Name} {
		
		if (Initial_Balance > 0){
			
			Balance = Initial_Balance;
		}
	}
		
		void Deposit (int Deposit_Amount){
			if(Deposit_Amount > 0){
				Balance = Balance + Deposit_Amount;
			}
		}
		
		void withdraws(int Withdraws_Amount){
			
			
			if (Balance - Withdraws_Amount >= 0){
				Balance = Balance - Withdraws_Amount;
			}
			else{
				std::cout << "Withdrawal amount exceeded account balance. \n";
			}
		}
			
		int getBalance() const{
			return Balance;
		}
		void Set_Name(std::string Account_Name){
			name = Account_Name;
		}
			
		std::string getName() const{
			return name;	
		}
				
private: 
					std::string name;
					int Balance = 0;
					
					
};