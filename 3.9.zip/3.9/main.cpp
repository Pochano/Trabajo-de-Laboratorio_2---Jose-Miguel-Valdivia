
#include <iostream>
#include "Account.cpp"

int main() {

	Account acount1{"Jane Green", 50};
  Account acount2{"Jhon Blue", -7};
  
	std::cout << "Account 1: " << acount1.getName() << " Balance: "<< acount1.getBalance() << "\n";

  std::cout << "Ingrese un monto a depositar: ";
  int deposito;
  std::cin >> deposito;
  acount1.Deposit(deposito); 
    
  	std::cout << "Account 1: " << acount1.getName() << " Balance: "<< acount1.getBalance() << "\n";

  std::cout << "Ingrese el monto a retirar: ";
  int retiro;
  std::cin >> retiro;
  acount1.withdraws(retiro);

  	std::cout << "Account 1: " << acount1.getName() << " Balance: "<< acount1.getBalance() << "\n";

  std::cout << "\n";

  std::cout << "Account 2: " << acount2.getName() << " Balance: "<< acount2.getBalance() << "\n";

  std::cout << "Ingrese un monto a depositar: ";
  int deposito2;
  std::cin >> deposito2;
  acount2.Deposit(deposito2);


  	std::cout << "Account 2: " << acount2.getName() << " Balance: "<< acount2.getBalance() << "\n";

  std::cout << "Ingrese el monto a retirar: ";
  int retiro2;
  std::cin >> retiro2;
  acount2.withdraws(retiro2);

  	std::cout << "Account 2: " << acount2.getName() << " Balance: "<< acount2.getBalance() << "\n";
  


  

	
}

